<?php
/*13.- Declara variables de diferentes tipos (entero, flotante, booleano) y muéstralas.
 */

$entero = 15; 
$flotante = 1.25; 
$booleano = true; 

echo "Un entero: $entero<br>";
echo "Un float: $flotante<br>";
echo "Un booleano: " . ($booleano ? 'true' : 'false') . "<br>";
?>
