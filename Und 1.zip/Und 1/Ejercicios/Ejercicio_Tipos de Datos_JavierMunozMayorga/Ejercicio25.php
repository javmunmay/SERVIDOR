<?php
$soyDesarrolladorWeb = true; 


if ($soyDesarrolladorWeb) {
    echo "Javier es Desarrollador Web";
} else {
    echo "Javier esta estudiando para ser Desarrollador Web";
}
?>
