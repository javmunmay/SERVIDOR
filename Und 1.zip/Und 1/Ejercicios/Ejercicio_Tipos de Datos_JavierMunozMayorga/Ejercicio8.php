<?php 
    // 8.- Modifica el script anterior para que el texto concatenado 
    //se muestre en líneas separadas.

    $cadena1 = "Buenos días, hoy es Miércoles";

    $cadena2 = " 25 de septiembre";
    
    echo "<p> La cadena '$cadena1' y '$cadena2' concatenada se ve así: $cadena1 \n $cadena2</p><br>"; 
    
    
    ?>