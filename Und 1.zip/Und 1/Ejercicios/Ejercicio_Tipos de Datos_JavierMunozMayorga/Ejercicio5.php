<?php 
/* 5.- Crea una cadena que incluya código HTML y CSS, utilizando comillas correctamente.*/


   echo "<p> Este es un codigo HTML y CSS: <h1 style=\"color:blue\"> Hola Mundo</h1> </p><br>"; 
    
    
?>