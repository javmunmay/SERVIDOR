<?php 
/* 3.- Crea una cadena en la que incluyas comillas simples y dobles.*/

    
    
    $cadena = "Buenos días, hoy 'Miércoles' 25 de \"Septiembre\" nos encontramos en clase trabajando";
    
    echo "<p> La cadena con comillas simples y dobles es: $cadena</p><br>"; 
    
    
    ?>