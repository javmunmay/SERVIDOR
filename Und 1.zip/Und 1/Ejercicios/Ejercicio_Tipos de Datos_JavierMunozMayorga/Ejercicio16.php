<?php
/*16.- Une variables y texto dentro de un echo
 */
$nombre = "Javier";
$edad = 22;

echo "Hola, mi nombre es $nombre y tengo $edad años.";
?>
