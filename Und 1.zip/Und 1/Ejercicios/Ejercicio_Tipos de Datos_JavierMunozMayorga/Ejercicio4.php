<?php 
/* 4.- Escribe dos cadenas, una con comillas simples y otra con comillas dobles, 
que incluyan una variable. Observa la diferencia.*/

    $diaDeLaSemana = 25;
    
    $cadenaComillasSimples = 'Buenos días, hoy es Miércoles';
    
    echo '<p> La cadena con comillas simples es: $cadenaComillasSimples &nbsp $diaDeLaSemana</p><br>'; 

    $cadenaComillasDobles = "Buenos días, hoy es Miércoles";
    
    echo "<p> La cadena con comillas dobles es: $cadenaComillasDobles &nbsp $diaDeLaSemana</p><br>"; 
    
    
    ?>