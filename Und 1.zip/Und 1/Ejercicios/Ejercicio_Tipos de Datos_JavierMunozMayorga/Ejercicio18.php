<?php
/*18.- Declara una variable entera y úsala en una operación.
 */

$numero = 5; 

$resultado = $numero * 2;

echo "El resultado de multiplicar $numero por 2 es: $resultado";
?>
