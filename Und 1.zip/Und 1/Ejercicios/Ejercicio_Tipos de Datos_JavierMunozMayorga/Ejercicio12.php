<?php
/*12.- Incluye una variable dentro de una cadena usando comillas dobles
 */
$nombre = "Javier";
echo "Hola, mi nombre es $nombre y este es el ejercicio 12 en PHP.";
?>