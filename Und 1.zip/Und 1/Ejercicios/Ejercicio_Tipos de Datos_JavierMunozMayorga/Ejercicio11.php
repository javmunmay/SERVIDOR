<?php

/*11.- Concatenar una variable y una cadena en una 
sola línea de texto.
*/
$nombre = "Javier";
echo "Hola, mi nombre es $nombre.";
?>
