<?php
/*10.- Usa varias variables 
en un cálculo simple y muestra el resultado*/

$numero1 = 20;
$numero2 = 10;

$suma = $numero1 + $numero2;
$resta = $numero1 - $numero2;
$multiplicacion = $numero2 * $numero1;
$division = $numero1 / $numero2;

echo"El valor numero 1 es: $numero1 y el valor numero 2 es: $numero2<br>";
echo "La suma de $numero1 + $numero2 es: " . $suma . "<br>";
echo "La resta de $numero1 - $numero2 es: " . $resta . "<br>";
echo "La multiplicacion de $numero1 * $numero2 es: " . $multiplicacion . "<br>";
echo "La division de $numero1 / $numero2 es: " . $division . "<br>";


?>