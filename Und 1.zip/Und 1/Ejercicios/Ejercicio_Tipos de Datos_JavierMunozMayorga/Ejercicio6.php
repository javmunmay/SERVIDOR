<?php 
/* 6.- Usa caracteres especiales como saltos de línea, 
tabulaciones o barras invertidas dentro de una cadena.*/


    $cadena = "Esto es \$ una cadena de \t prueba para \n aprender php";
    
    echo nl2br( $cadena );   
     
    
    

?>