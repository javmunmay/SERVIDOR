<?php
//Declara una variable y asígnale un valor. Luego, imprímela en pantalla.

$numero = 7;
$texto = "El número es: ";
echo $texto . $numero;

?>