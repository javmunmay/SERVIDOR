<?php
/*20.- Usa una variable de tipo flotante y realiza una operación con ella.
*/

$precio = 7.99; 
$descuento = 0.20; 


$precioFinal = $precio - ($precio * $descuento);

echo "El precio final después del 20% dto es: " . $precioFinal. " € ";
?>
