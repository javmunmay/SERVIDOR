<?php 
/* 7.- Concatenar dos cadenas y mostrar el resultado.*/

    $cadena1 = "Buenos días, hoy es Miércoles";

    $cadena2 = " 25 de septiembre";
    
    echo "<p> La cadena '$cadena1' y '$cadena2' concatenada se ve así: $cadena1 $cadena2</p><br>"; 
    
    
    ?>