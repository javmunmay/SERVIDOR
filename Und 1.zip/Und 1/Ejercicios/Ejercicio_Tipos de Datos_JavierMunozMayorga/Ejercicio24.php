<?php
/*24.- Realiza una operación entre diferentes tipos de datos (flotante y entero) y observa la conversión automática.
*/

$entero = 10; 
$float = 9.5; 


$resultado = $entero + $float;

echo "El resultado de la suma entre $entero (entero) y $float (float) es: $resultado";
?>
