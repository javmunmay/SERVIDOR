<?php
/*17.- Declara una variable booleana y usa un if para mostrar un mensaje dependiendo de su valor.
*/
$esMayorDeEdad = true;

if ($esMayorDeEdad) {
    echo "Eres mayor de edad.";
} else {
    echo "Eres menor de edad.";
}
?>
