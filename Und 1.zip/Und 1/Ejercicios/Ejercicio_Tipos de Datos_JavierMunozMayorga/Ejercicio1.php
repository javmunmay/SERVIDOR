<?php 
/* 1.- Crea un script en PHP que declare y muestre diferentes tipos de datos: 
    enteros, flotantes, cadenas y booleanos.*/

    
    $entero = 1;
    $flotante = 9.5;
    $cadena = "Hola";
    $booleano = true;


    echo "<p> Entero: $entero</p><br>"; 
    echo"<p>flotante: $flotante</p><br>";
    echo"<p>cadena: $cadena</p><br>";
    echo"<p>booleano: $booleano</p><br>";

    
    
    
    ?>