<?php
/*23.- Convierte explícitamente una variable flotante en entera.
*/

$nota = 9.95; 

//Convertirlo a entero:
$notaEnEntero = (int)$nota;

echo "El número flotante es: $nota<br>";
echo "El número convertido en entero es: $notaEnEntero";
?>
