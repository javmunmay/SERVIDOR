<?php
$num1 = 20;
$num2 = 3;

//Calcular el resto y el cociente:
$cociente = intdiv($num1,$num2);
$resto = $num1 % $num2;

echo "El cociente de $num1 dividido entre $num2 es: $cociente <br>";
echo "El resto de $num1 dividido entre $num2 es: $resto";


?>