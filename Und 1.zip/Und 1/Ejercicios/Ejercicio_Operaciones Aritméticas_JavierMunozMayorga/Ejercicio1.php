<?php
$ancho = 55;
$alto = 20;

//Calcular el area:
$area = $ancho*$alto;
$perimetro = 2*($ancho+$alto);

echo"El area del rectangulo es: $area <br>";
echo"El Perimetro del rectangulo es: $perimetro";


?>