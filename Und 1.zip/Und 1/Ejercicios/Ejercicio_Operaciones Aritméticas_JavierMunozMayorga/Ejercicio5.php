<?php

$base = 2;
$exponente = 3;

// Calcular la potencia
$resultado = $base ** $exponente;


echo "$base elevado a la $exponente potencia es: $resultado";
?>
