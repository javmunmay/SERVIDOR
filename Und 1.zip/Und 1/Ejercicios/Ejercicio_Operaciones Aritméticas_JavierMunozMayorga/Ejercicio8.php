<?php

$numero = 901250.258694;

// Formatear el número con separador de miles y 3 decimales
$numeroFormateado = number_format($numero, 3, ',', '.');


echo "El número formateado es: $numeroFormateado";
?>
