<?php
// Generar un número aleatorio entre 1 y 50
$numero_aleatorio = mt_rand(1, 50);


echo "El número aleatorio entre 1 y 50 es: $numero_aleatorio";
?>
