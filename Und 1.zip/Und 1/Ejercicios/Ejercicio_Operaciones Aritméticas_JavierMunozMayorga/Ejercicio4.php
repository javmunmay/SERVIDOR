<?php

$num = 5.24782;

// Redondear el número a 2 decimales
$numRedondeado = round($num, 2);


echo "El número original es: $num <br>";
echo "El número redondeado a 2 decimales es: $numRedondeado";
?>
