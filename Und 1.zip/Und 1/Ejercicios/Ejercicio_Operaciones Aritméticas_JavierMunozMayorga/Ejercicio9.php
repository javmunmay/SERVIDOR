<?php
$numero = 6;

if ($numero>=10 && $numero<= 20) {
    echo"Sí esta entre 10 y 20";
} else {
    echo"No esta entre 10 y 20";
}

?>